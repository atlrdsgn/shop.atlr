const globalKitZIndices = {
  zIndices: {
    0: '1',
    1: '100',
    2: '200',
    3: '300',
    4: '400',
    max: '999'
  }
}

export const kitZIndices = globalKitZIndices
