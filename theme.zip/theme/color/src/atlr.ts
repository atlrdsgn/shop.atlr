const a = {
  atlr1: '#CEFE71',
  atlr2: '#BEBCA6',
  atlr3: '#A493F8',
  atlr4: '#837E95',

  matte: '#050507'
}

const aDark = {
  atlr1: '#A493F8',
  atlr2: '#837E95',
  atlr3: '#CEFE71',
  atlr4: '#BEBCA6',

  matte: '#C4C6CD'
}

export const atlr = a
export const atlrDark = aDark
