export {kitFonts} from './kit.fonts'
